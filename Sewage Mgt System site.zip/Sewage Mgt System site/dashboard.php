<?php
  session_start();
    
    if (($_SESSION['account'] === "false") || ($_SESSION['account'] == "")) { /*Preventing one to access the system when a session has not been created*/
        # code...
        header('Location: index.php');
    }

  include 'includes/header.php';
  $_SESSION["error"] = "";


?>
      <!--_navbar.php -->

<?php 

    include 'includes/nav.php';

?>
      <!-- partial -->


      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
      
         <?php  
          include 'includes/sidebar.php';
        ?>

        <!-- partial -->
        <div class="main-panel">

 
          
<!-- 
    <div class="wrapper pr-3 mt-2" style="float: left;">
        
    </div> -->
    <style type="text/css">
            /* Make sure that padding behaves as expected */
            * {box-sizing:border-box}

            /* Container for skill bars */
            .container {
              width: 100%; /* Full width */
             /* background-color: #ddd; /* Grey background */
            }

            .skills {
              text-align: right; /* Right-align text */
              padding-top: 10px; /* Add top padding */
              padding-bottom: 10px; /* Add bottom padding */
              color: white; /* White text color */
            }

            .normal {width: 60%; background-color: #4CAF50;}  /* Green */
            .medium {width: 20%; background-color: #2196F3;} /* Blue */
            .attention {width: 20%; background-color: #f44336;} /* Red */


* {
box-sizing: border-box;
}

/*body {
background: #34495e;
font-family: 'ZCOOL XiaoWei', serif;
display: flex;
align-items: center;
justify-content: center;
height: 100vh;
margin: 0;
}*/

.container {
background: #fff;
display: flex;
align-items: center;
justify-content: center;
flex-direction: column;
overflow: hidden;
text-align: center;
width: 280px;
height: 120px;
}

.container h3 {
color: #111;
margin: 0 0 25px;
position: relative;
z-index: 2;
}

.checkbox-container {
display: inline-block;
position: relative;
}

.checkbox-container label {
background-color: #aaa;
border: 1px solid #fff;
border-radius: 20px;
display: inline-block;
position: relative;
transition: all 0.3s ease-out;
width: 45px;
height: 25px;
z-index: 2;
}

.checkbox-container label::after {
content: ' ';
background-color: #fff;
border-radius: 50%;
position: absolute;
top: 1.5px;
left: 1px;
transform: translateX(0);
transition: transform 0.3s linear;
width: 20px;
height: 20px;
z-index: 3;
}

.checkbox-container input {
visibility: hidden;
position: absolute;
z-index: 2;
}

.checkbox-container input:checked + label + .active-circle {
transform: translate(-50%, -50%) scale(15);
}

.checkbox-container input:checked + label::after {
transform: translateX(calc(100% + 0.5px));
}

.active-circle {
border-radius: 50%;
position: absolute;
top: 50%;
left: 50%;
transform: translate(calc(-50% - 10px), calc(-50% - 2px)) scale(0);
transition: transform 0.6s ease-out;
width: 100px;
height: 100px;
z-index: 1;
}

.checkbox-container.green .active-circle,
.checkbox-container.green input:checked + label {
background-color: #47B881;
}

.checkbox-container.yellow .active-circle,
.checkbox-container.yellow input:checked + label {
background-color: #F7D154;
}

.checkbox-container.purple .active-circle,
.checkbox-container.purple input:checked + label {
background-color: #735DD0;
}

    </style> 

         <!-- <div class="container" align="center"> -->
          <!-- <div class="card">
            <div class="card-body"> -->

   <!--    <h3>Pump Status<span id="status"></span></h3>
      <div class="checkbox-container yellow">
      <input type="checkbox" id="toggle" onclick="state();" />
      <label for="toggle"></label> 
      <div class="active-circle"></div> 
      </div> -->
              
           <!--  </div>
          </div> -->
        <!-- </div>
 -->    <div class="row">
      <div class="col-sm-1"></div>
      <div class="container col-sm-5"  style="margin-top: 20px;">
        <div>
                <h3><span id="status"></span></h3>
              <!-- <div class="checkbox-container yellow">
              <input type="checkbox" id="toggle" onclick="state();" />
              <label for="toggle"></label> 
              <div class="active-circle"></div> 
              </div>
            
 -->        </div>
              
      </div>
  <div class="col-sm-6">
     <div  style="margin-top: 15px;" >

                         <div class="wrapper pr-3 mt-10" style="margin-top: 15px;">
                              <div class="container" style="margin-bottom: 15px;">
                                <span style="color: #4CAF50; ">System Status ( <span id="staten" style="color: green;"> </span> <span id="statea" style="color: blue;"> </span> <span id="stated" style="color: red;"> </span>) </span>
                                <div class="skills normal">
                                  
                                    <span id="statusresult"> </span>
                                </div>
                              </div>

                              
                           



                         </div>

                      </div>

     </div>
 <div class="col-sm-1"></div>
</div>
<div class="row">
    <div class="col-sm-2"></div>
      <div class="col-sm-10" style="margin-top: 10px;">

                      <div style="float: left;">
                        <div class="wrapper pr-3 mt-4">
                          <center> <h5 class="mb-0">Location 1</h5>
                           <h4 class="font-weight-semibold mb-0" id="re_ph">0</h4> </center>

                           <canvas class="mt-0" height="140" id="canvas"  style="width: 100%;"></canvas>

                        </div>

                        <div class="mt-4">
                           <center> <h5 class="mb-0">location 2<small class=""></small> </h5>
                           <h4 class="font-weight-semibold mb-0" id="re_ec">0</h4> </center>
                           <canvas class="mt-0" height="140" id="canvas_ec"></canvas>
                        </div>
                      </div>

                          <div style="float: left;">
                           <div class="wrapper pr-3 mt-4">
                          <center> <h5 class="mb-0">Location 3</h5>
                           <h4 class="font-weight-semibold mb-0" id="re_temp">0</h4> </center>

                           <canvas class="mt-0" height="140" id="canvas_temp" style="width: 100%;"></canvas>

                        </div>

                        <div class="mt-4" style="">
                           <center> <h5 class="mb-0">Location 4<small class=""></small>  
                            <!-- <button onclick="updateconfig_water()">update</button>  -->
                            
                           </h5>
                           <h4 class="font-weight-semibold mb-0" id="re_levels">0</h4> </center>
                           <canvas class="mt-0" height="140" id="canvas_water"></canvas>
                        </div>

                      </div>
      
 <!-- <input type="text" value="<?php // echo $_SESSION['username']; ?>" name="" id="sysid_in"> -->
<!-- <span id="sysid"> --> <?php // echo $_SESSION['username']; ?> <!-- </span>  -->


</div>
<div style="margin-bottom: 50px;">.</div>
<script type="text/javascript">
                function loadallsysdetails(){
                var sysid = <?php echo $_SESSION['username']; ?>;
                var posting = $.post('../v1/includes/fetch_details.php', { sysid: sysid} );
                posting.done(function(data){
                  //document.getElementById('re_temp').innerHTML = data;
                 // alert(data[0].sysid);
                     var tempjs = "";
                     var Levelsjs= "";
                     var ecjs= "";
                     var phjs = "";
                     var newdata_ph = [];
                     var newdata_water=[];
                     var newdata_ec = [];
                     var newdata_temp = [];
                     var newdataphnotify = 0;
                     var newdataecnotify = 0;
                     var newdatalevelnotify = 0;
                     var newdatatempnotify = 0;
                     var j = 0;
                    for (var i=0; i< data.length; i++) {    
                        //console.log(data[i].agent_names);

                        var regsysid = data[i].sysid; 
                        if (regsysid == sysid) {
                          j = j+1;
                         // var regph = data[i].ph;

                          var tempjs = data[i].temp;
                          var Levelsjs= data[i].levels;
                          var ecjs= data[i].ec;
                          var phjs = data[i].ph;

                          newdata_ph.push(phjs);
                          newdata_water.push(Levelsjs);
                          newdata_ec.push(ecjs);
                          newdata_temp.push(tempjs);

                          
                         // if (newdata_ph.length > 2) {

                         // }
                           //for (var i=0; i<newdata_ph.length ; i--) {
                           //   if (i<=2) { 
                            //    regnewdata_ph.push(newdata_ph[i]);
                           //   }
                           //}
                          //alert(regph);


                        }


                        var sysidnoifier = data[i].sysnotify;
                        if (regsysid == sysidnoifier) {
                          newdataphnotify = data[i].phnotify; 
                          newdataecnotify = data[i].ecnotify;
                          newdatalevelnotify = data[i].levelnotify;
                          newdatatempnotify = data[i].tempnotify;
                        }

                        //alert(sysid);
                    }

                     var cur_ecjs = newdata_ec[0];
                     var cur_Levelsjs = newdata_water[0];
                     var cur_tempjs = newdata_temp[0];
                     var cur_phjs = newdata_ph[0];


                     document.getElementById('re_temp').innerHTML = cur_tempjs;
                     document.getElementById('re_levels').innerHTML = cur_Levelsjs;
                     document.getElementById('re_ec').innerHTML = cur_ecjs;
                     document.getElementById('re_ph').innerHTML = cur_phjs;

                  //    j = j+1;
                  //  }
                    //alert(newdata_ph);

                          updateconfig_ph(newdata_ph); // this is for ph
                          updateconfig_water(newdata_water);
                          updateconfig_ec(newdata_ec);
                          updateconfig_temp(newdata_temp);

                          var conterph1 = 0;
                          var conterph2 = 0;
                          var conterph3 = 0;

                          var conterec1 = 0;
                          var conterec2 = 0;
                          var conterec3 = 0;

                          var contertemp1 = 0;
                          var contertemp2 = 0;
                          var contertemp3 = 0;

                          var conterlevel1 = 0;
                          var conterlevel2 = 0;
                          var conterlevel3 = 0;

                          if (newdataphnotify != 0) {
                            if(cur_phjs < 7){
                              alert("PH requires attension");
                              conterph2 = 3;
                            }
                            else if(cur_phjs > 9.45){
                              alert("PH requires attension");
                              conterph3 = 7;
                            }
                            else{
                               conterph1 = 15;
                            }

                   }

                 //  alert(conterph2);

                   if (newdataecnotify != 0) {
                   // alert("EC requires attension");
                    if(cur_ecjs < 400){
                              alert("EC requires attension");
                              conterec2 = 3;
                            }
                   if(cur_ecjs > 1000){
                     alert("EC requires attension");
                            conterec3 = 7;
                            }
                   else{
                       conterec1 = 15;
                    }

                   }
                   if (newdatatempnotify != 0) {
                    
                    if(cur_tempjs < 400){
                              alert("EC requires attension");
                              contertemp2 = 3;
                            }
                   if(cur_tempjs > 1000){
                     alert("EC requires attension");
                              contertemp3 = 3;
                            
                            }
                   else{
                       contertemp1 = 15;
                    }
                   }
                   if (newdatalevelnotify != 0) {
                    if (cur_Levelsjs = 0) {
                    alert("Water Level requires attension");
                    conterlevel1 = 0;
                    }
                    else{
                    conterlevel1 = 25;

                    }

                   }
                   
                   // COMPUTE SYSTEM STATES
                   // ph
                 if(cur_phjs < 7){
                             // alert("PH requires attension");
                              conterph2 = 3;
                            }
                            else if(cur_phjs > 9.45){
                             // alert("PH requires attension");
                              conterph3 = 7;
                            }
                            else{
                               conterph1 = 15;
                            }

                   var phstate =  conterph2 + conterph3 + conterph1;
                  // alert(phstate);
                   // EC
                 if(cur_ecjs < 400){
                             // alert("PH requires attension");
                              conterec2 = 3;
                            }
                            else if(cur_phjs > 1000){
                             // alert("PH requires attension");
                              conterec3 = 7;
                            }
                            else{
                               conterec1 = 15;
                            }

                   var ecstate =  conterec2 + conterec3 + conterec1;
                  // alert(ecstate);
                  // TEMP
                 if(cur_tempjs < 18){
                             // alert("PH requires attension");
                              contertemp2 = 3;
                            }
                            else if(cur_tempjs > 26){
                             // alert("PH requires attension");
                              contertemp3 = 7;
                            }
                            else{
                               contertemp1 = 15;
                            }

                   var tempstate =  contertemp2 + contertemp3 + contertemp1;
                  // alert(tempstate);
                     // LEVELS
                 if(cur_Levelsjs == 0){
                             // alert("PH requires attension");
                              conterlevel1 = 18;
                            }
                            else{
                               conterlevel2 = 15;
                            }

                   var levelstate =  conterlevel1 + conterlevel2;
                    var systat = levelstate + tempstate + ecstate + phstate;
                   // alert(systat);
                  //document.getElementById('statusresult').innerHTML = systat + "%";

                   if (systat >= 65 ) {
                  //document.getElementById("normal").style.color = "blue";
                  document.getElementById('statea').innerHTML = "";
                  document.getElementById('stated').innerHTML = "";
                  document.getElementById('staten').innerHTML = "Normal";
                  document.getElementById('statusresult').innerHTML = systat + "%"; 
                }
                if ((systat >= 50) & (systat < 65)) {
                  //document.getElementById("normal").style.color = "blue";
                  document.getElementById('stated').innerHTML = "";
                  document.getElementById('staten').innerHTML = "";
                  document.getElementById('statea').innerHTML = "Average";
                  document.getElementById('statusresult').innerHTML = systat + "%"; 
                }
                if (systat < 50 ) {
                  document.getElementById('statea').innerHTML = "";
                  document.getElementById('staten').innerHTML = "";
                  //document.getElementById("normal").style.color = "blue";
                  document.getElementById('stated').innerHTML = "Attention";
                  document.getElementById('statusresult').innerHTML = systat + "%"; 
                }


                });

               //alert(sysid);
            }
</script>

<script type="text/javascript">
  // read current sensor values

    setInterval(function () { 
                  
                   loadallsysdetails()
                      
             }, 1500); // it will call   
</script>

<script type="text/javascript">
  // read computins for system state
    setInterval(function () { 
                  
                   $.post( '../v1/includes/status.php',
               function( response ) {
                //console.log(response); state
                // if (response >= 65 ) {
                //   //document.getElementById("normal").style.color = "blue";
                //   document.getElementById('statea').innerHTML = "";
                //   document.getElementById('stated').innerHTML = "";
                //   document.getElementById('staten').innerHTML = "Normal";
                //   document.getElementById('statusresult').innerHTML = response + "%"; 
                // }
                // if ((response >= 50) & (response < 65)) {
                //   //document.getElementById("normal").style.color = "blue";
                //   document.getElementById('stated').innerHTML = "";
                //   document.getElementById('staten').innerHTML = "";
                //   document.getElementById('statea').innerHTML = "Average";
                //   document.getElementById('statusresult').innerHTML = response + "%"; 
                // }
                // if (response < 50 ) {
                //   document.getElementById('statea').innerHTML = "";
                //   document.getElementById('staten').innerHTML = "";
                //   //document.getElementById("normal").style.color = "blue";
                //   document.getElementById('stated').innerHTML = "Attention";
                //   document.getElementById('statusresult').innerHTML = response + "%"; 
                // }
                
                 
               }
            );
                      
             }, 150); // it will call   
</script>

<?php 

    include 'includes/footer.php';

?>
      <!-- partial -->