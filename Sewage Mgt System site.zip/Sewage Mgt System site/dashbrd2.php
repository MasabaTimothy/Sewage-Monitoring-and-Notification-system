<?php
  session_start();
    
    if (($_SESSION['account'] === "false") || ($_SESSION['account'] == "")) { /*Preventing one to access the system when a session has not been created*/
        # code...
        header('Location: index.php');
    }

  include 'includes/header.php';
  $_SESSION["error"] = "";


?>
      <!--_navbar.php -->

<?php 

    include 'includes/nav.php';

?>
      <!-- partial -->


      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
      
         <?php  
          include 'includes/sidebar.php';
        ?>

        <!-- partial -->
        <div class="main-panel">

 
          
<!-- 
    <div class="wrapper pr-3 mt-2" style="float: left;">
        
    </div> -->
    <style type="text/css">
            /* Make sure that padding behaves as expected */
            * {box-sizing:border-box}

            /* Container for skill bars */
            .container {
              width: 100%; /* Full width */
             /* background-color: #ddd; /* Grey background */
            }

            .skills {
              text-align: right; /* Right-align text */
              padding-top: 10px; /* Add top padding */
              padding-bottom: 10px; /* Add bottom padding */
              color: white; /* White text color */
            }

            .normal {width: 60%; background-color: #4CAF50;}  /* Green */
            .medium {width: 20%; background-color: #2196F3;} /* Blue */
            .attention {width: 20%; background-color: #f44336;} /* Red */

    </style>
    <div class="row">
      <div class="col-1"></div>
  <div class="col-3">
     <div  style="margin-top: 80px;" >

                         <div class="wrapper pr-3 mt-10" style="margin-top: 15px;">
                              <div class="container" style="margin-bottom: 15px;">
                                <span style="color: #4CAF50; ">System Status ( <span id="staten" style="color: green;"> </span> <span id="statea" style="color: blue;"> </span> <span id="stated" style="color: red;"> </span>) </span>
                                <div class="skills normal">
                                  
                                    <span id="statusresult"> </span>
                                </div>
                              </div>

                              
                             <!--  <div class="container"  style="margin-bottom: 15px;">
                                <span style="color: #2196F3; ">Average</span>
                                <div class="skills medium" >
                                </div>
                              </div> -->

                              
                              <!-- <div class="container"  style="margin-bottom: 15px;">
                                <span style="color: #f44336; ">Attention</span>
                                <div class="skills attention">20%</div>
                              </div> -->

                         </div>

                      </div>

     </div>

      <div class="col-8" style="margin-top: 10px;">

                      <div style="float: left;">
                        <div class="wrapper pr-3 mt-4">
                          <center> <h5 class="mb-0">PH</h5>
                           <h4 class="font-weight-semibold mb-0" id="re_ph">0</h4> </center>

                           <canvas class="mt-0" height="140" id="canvas"></canvas>

                        </div>

                        <div class="mt-4">
                           <center> <h5 class="mb-0">Electrical Conductivity *(ms/cm)<small class=""></small> </h5>
                           <h4 class="font-weight-semibold mb-0" id="re_ec">0</h4> </center>
                           <canvas class="mt-0" height="140" id="canvas_ec"></canvas>
                        </div>
                      </div>

                          <div style="float: left;">
                           <div class="wrapper pr-3 mt-4">
                          <center> <h5 class="mb-0">Temperature *(&#8451;)</h5>
                           <h4 class="font-weight-semibold mb-0" id="re_temp">0</h4> </center>

                           <canvas class="mt-0" height="140" id="canvas_temp"></canvas>

                        </div>

                        <div class="mt-4" style="">
                           <center> <h5 class="mb-0">Water Levels *(%) <small class=""></small>  <button onclick="updateconfig_water()">update</button> </h5>
                           <h4 class="font-weight-semibold mb-0" id="re_levels">0</h4> </center>
                           <canvas class="mt-0" height="140" id="canvas_water"></canvas>
                        </div>

                      </div>
      
<input type="hidden" value="<?php echo $_SESSION['username']; ?>" name="" id="sysid_in">

</div>

<script type="text/javascript">
      function loadphvalues(){
                var sysid = $("#sys_id").text();
                //var sysid = document.getElementById("sys_id").innerText;
                //alert(sysid);
                var posting = $.post('../v1/includes/currentphreading.php', { sysid: sysid} );
                posting.done(function(data){
                  document.getElementById('re_ph').innerHTML = data;

                });

               //alert(sysid);

            }

            // ec value
            function loadecvalues(){
                var sysid = $("#sysid_in").val();
                var posting = $.post('../v1/includes/currentecreading.php', { sysid: sysid} );
                posting.done(function(data){
                  document.getElementById('re_ec').innerHTML = data;

                });
              }
               //alert(sysid);

                     // water level value
            function loadwatvalues(){
                var sysid = $("#sysid_in").val();
                var posting = $.post('../v1/includes/currentwatreading.php', { sysid: sysid} );
                posting.done(function(data){
                  document.getElementById('re_levels').innerHTML = data;

                });

               //alert(sysid);
            }
            // temp values
             function loadtempvalues(){
                var sysid = $("#sysid_in").val();
                var posting = $.post('../v1/includes/currenttempreading.php', { sysid: sysid} );
                posting.done(function(data){
                  document.getElementById('re_temp').innerHTML = data;

                });

               //alert(sysid);
            }

</script>

<script type="text/javascript">
  // read current sensor values
    setInterval(function () { 
                  
                   loadphvalues()
                   loadecvalues()
                   loadtempvalues()
                   loadwatvalues()
                      
             }, 150); // it will call   
</script>

<script type="text/javascript">
  // read computins for system state
    setInterval(function () { 
                  
                   $.post( '../v1/includes/status.php',
               function( response ) {
                //console.log(response); state
                if (response >= 65 ) {
                  //document.getElementById("normal").style.color = "blue";
                  document.getElementById('statea').innerHTML = "";
                  document.getElementById('stated').innerHTML = "";
                  document.getElementById('staten').innerHTML = "Normal";
                  document.getElementById('statusresult').innerHTML = response + "%"; 
                }
                if ((response >= 50) & (response < 65)) {
                  //document.getElementById("normal").style.color = "blue";
                  document.getElementById('stated').innerHTML = "";
                  document.getElementById('staten').innerHTML = "";
                  document.getElementById('statea').innerHTML = "Average";
                  document.getElementById('statusresult').innerHTML = response + "%"; 
                }
                if (response < 50 ) {
                  document.getElementById('statea').innerHTML = "";
                  document.getElementById('staten').innerHTML = "";
                  //document.getElementById("normal").style.color = "blue";
                  document.getElementById('stated').innerHTML = "Attention";
                  document.getElementById('statusresult').innerHTML = response + "%"; 
                }
                
                 
               }
            );
                      
             }, 150); // it will call   
</script>

<?php 

    include 'includes/footer.php';

?>
      <!-- partial -->