<?php
	
  //          ob_start();
   session_start();

   if ($_SESSION['account'] === "false") { /*Preventing one to access the system when a session has not been created*/
        # code...
        header('Location: /agritech/v1/index.php');
        //$Error = '';
        /*Redirecting to the login page*/
    }
      //include 'checksession.php';
   else { /*Preventing one to access the system when a session has not been created*/
        # code...
         header("Location: /agritech/v1/dashbrd.php");
 //       $Error = '';
        /*Redirecting to the login page*/
    } 

?>