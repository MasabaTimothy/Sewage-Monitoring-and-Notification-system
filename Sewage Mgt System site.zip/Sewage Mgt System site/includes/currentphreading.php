<?php

  include '../config/connection.php';
  session_start();
  //$current[] =array();
  $sysid = $_GET['sysid'];
  //echo $sysid;
  $status_sql = "SELECT * FROM `datavalues` WHERE  ORDER BY dataid ASC ";
  $status_result = $conn->query($status_sql);
 
              // session_start();
                 while($status_row = $status_result->fetch_assoc()) {
                    $id = $status_row['sysid'];
                    if ($sysid = $id) {
                      # code...
                      $ph = $status_row["ph"];
                    }
                    else{
                      $ph = 0;
                    }
                    
                 }
                echo $ph;
      
?>