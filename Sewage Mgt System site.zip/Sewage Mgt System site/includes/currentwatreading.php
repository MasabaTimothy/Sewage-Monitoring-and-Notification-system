<?php

  include '../config/connection.php';
  session_start();
  //$current[] =array();
  $sysid = $_GET['sysid'];
  //echo $sysid;
  $status_sql = "SELECT * FROM `datavalues` ORDER BY dataid ASC";
  $status_result = $conn->query($status_sql);
 
              // session_start();
                 while($status_row = $status_result->fetch_assoc()) {
                  if ($sysid = $status_row['sysid']) {
                      # code...
                      $levels = $status_row["levels"];
                    }
                 }
                echo $levels;
      
?>