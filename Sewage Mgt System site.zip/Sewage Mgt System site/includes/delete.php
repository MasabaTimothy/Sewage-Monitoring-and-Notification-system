<?php

 include '../config/connection.php';


$conn->query("DELETE FROM `datavalues` WHERE sysid = 1234") or die(mysqli_error());

echo "off";

?>
//