<?php
//setting header to json
header('Content-Type: application/json');

//Connect to the server and database
 include '../config/connection.php';
  session_start();
 // $sysid = $_SESSION['username'];

//fetch for display
// $query = "SELECT * FROM datavalues ORDER BY dataid DESC";
$query = "SELECT * FROM datavalues ORDER BY dataid DESC";
//execute query

$result = mysqli_query($conn, $query);
//$result = $mysqli->query($query);

//loop through the returned data
$data = array();
$sysdetails = array();
//$newdata = array();

 $querynotify = "SELECT * FROM notifications";
// //execute query

 $resultnotify = mysqli_query($conn, $querynotify);

 	while ($rownotify = $resultnotify->fetch_assoc()) {
 		$phnotify = $rownotify['ph'];
 		$ecnotify = $rownotify['ec'];
 		$levelnotify = $rownotify['level'];
 		$tempnotify = $rownotify['temp'];
 		$sysnotify = $rownotify['sysid'];
 	}

while ($row = $result->fetch_assoc()) {

	$sysid =  $row['sysid'];
	$levels =  $row['levels'];
	$ph =  $row['ph'];
	$temp =  $row['temp'];
	$ec =  $row['ec'];
	//array_push($newdata, $ph);

	$sysdetails[] = array("sysid"=>$sysid,"phnotify"=>$phnotify,"ecnotify"=>$ecnotify,"levelnotify"=>$levelnotify,"tempnotify"=>$tempnotify,"sysnotify"=>$sysnotify,"levels"=>$levels,"ph"=>$ph,"temp"=>$temp,"ec"=>$ec);

}


print json_encode($sysdetails);

//echo $sys;

$result->close();


?>
