<footer class="footer" style="position: fixed; left: 0; bottom: 0; width: 100%;">
  <div class="container-fluid clearfix">
    <center>
     <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © <small><?php echo date('Y'); ?> </small> SEWAGE MONITORING </span> 
     </center>

  </div>
</footer>
        </div>
      </div>
    </div>



<?php

  include 'includes/scripts.php';

?>