<script>
      function state() {
          if(document.getElementById('toggle').checked) {
               $.post( 'includes/turnon.php',
               function( response ) {
               // document.getElementById('mod2').style.backgroundColor= "grey";
                document.getElementById('status').innerHTML = ':on';
                 //alert(response);
                // $( "#result" ).html( response );
                 //alert('ON');
               }
            );
          } else {
              $.post( 'includes/turnoff.php',
               function( response ) {
              //  document.getElementById('mod2').style.backgroundColor= "red";
                document.getElementById('status').innerHTML = ':off';
                 //alert(response);
                // $( "#result" ).html( response );
                 //alert(OFF);
               }
            );
          }
      }

      // notification

           function phstate() {
          if(document.getElementById('toggle4').checked) {
               $.post( 'includes/phturnon.php',
               function( response ) {
               // document.getElementById('mod2').style.backgroundColor= "grey";
                document.getElementById('toggle4').innerHTML = ':on';
                 alert("Ph Notifications: ON");
                // $( "#result" ).html( response );
                 <?php  $checker = "true"; ?>
               }
            );
          } else {
              $.post( 'includes/phturnoff.php',
               function( response ) {
              //  document.getElementById('mod2').style.backgroundColor= "red";
                document.getElementById('toggle4').innerHTML = ':off';
                alert("Ph Notifications: OFF");
                <?php  $checker = "false"; ?>
                 //alert(response);
                // $( "#result" ).html( response );
                 //alert(OFF);
               }
            );
          }
      }
        
                   function ecstate() {
          if(document.getElementById('toggle3').checked) {
               $.post( 'includes/ecturnon.php',
               function( response ) {
               // document.getElementById('mod2').style.backgroundColor= "grey";
                document.getElementById('toggle3').innerHTML = ':on';
                 alert("EC Notifications: ON");
                // $( "#result" ).html( response );
                 <?php  $ecchecker = "true"; ?>
               }
            );
          } else {
              $.post( 'includes/ecturnoff.php',
               function( response ) {
              //  document.getElementById('mod2').style.backgroundColor= "red";
                document.getElementById('toggle3').innerHTML = ':off';
                alert("EC Notifications: OFF");
                <?php  $ecchecker = "false"; ?>
                 //alert(response);
                // $( "#result" ).html( response );
                 //alert(OFF);
               }
            );
          }
      }

                         function levelstate() {
          if(document.getElementById('toggle5').checked) {
               $.post( 'includes/levelturnon.php',
               function( response ) {
               // document.getElementById('mod2').style.backgroundColor= "grey";
                document.getElementById('toggle5').innerHTML = ':on';
                 alert("Level Notifications: ON");
                // $( "#result" ).html( response );
                 <?php  $levelchecker = "true"; ?>
               }
            );
          } else {
              $.post( 'includes/levelturnoff.php',
               function( response ) {
              //  document.getElementById('mod2').style.backgroundColor= "red";
                document.getElementById('toggle5').innerHTML = ':off';
                alert("Level Notifications: OFF");
                <?php  $levelchecker = "false"; ?>
                 //alert(response);
                // $( "#result" ).html( response );
                 //alert(OFF);
               }
            );
          }
      }


                         function tempstate() {
          if(document.getElementById('toggle2').checked) {
               $.post( 'includes/tempturnon.php',
               function( response ) {
               // document.getElementById('mod2').style.backgroundColor= "grey";
                // document.getElementById('toggle2').innerHTML = ':on';
                 alert("Temperture Notifications: ON");
                // $( "#result" ).html( response );
                 <?php  $tempchecker = "true"; ?>
               }
            );
          } else {
              $.post( 'includes/tempturnoff.php',
               function( response ) {
              //  document.getElementById('mod2').style.backgroundColor= "red";
                // document.getElementById('toggle2').innerHTML = ':off';
                alert("Temperature Notifications: OFF");
                <?php  $tempchecker = "false"; ?>
                 //alert(response);
                // $( "#result" ).html( response );
                 //alert(OFF);
               }
            );
          }
      }
</script>


<?php 
  // ob_start();
   //session_start();
 
  // include 'checksession.php';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sewage<?php // echo $_SESSION['account']; ?> </title>
    <!-- plugins:css -->
    <script src="assets/dist/Chart.bundle.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <link rel="stylesheet" href="assets/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/iconfonts/ionicons/dist/css/ionicons.css">
    <link rel="stylesheet" href="assets/vendors/iconfonts/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.addons.css">
    <link rel="stylesheet" href="assets/css/alert.css">

    <link rel="shortcut icon" href="assets/images/favicon.ico" />
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="assets/css/shared/style.css">
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/demo_1/style.css">
    <!-- <link rel="stylesheet" href="assets/dist/css/bootstrap.css"> -->
    <!-- End Layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />

    <script src="assets/vendors/chartjs/Chart.min.js"></script>  
    <script src="assets/js/alert.js"></script>       
  </head>
  <body>
    <div class="container-scroller"> 
      <style type="text/css">
        .navbar.default-layout .navbar-brand-wrapper{
          background: #ffffff;
        }
      </style>