<?php

 include '../config/connection.php';

session_start();
$usrid = $_SESSION['username'];
//$usrid = $_GET['sysid']; levelturnof.php
$status = 0; 
$counter = 0;
//$select = $conn->query("SELECT * FROM `notifications` WHERE `notificationsid` = '$usrid'") or die(mysqli_error());
$query = "SELECT * FROM `notifications` WHERE `sysid` = '$usrid'";
$result = mysqli_query($conn, $query);
while ($row = $result->fetch_assoc()) {
	$counter = $counter + 1;
}

if ($counter > 0) {
	# code...
$conn->query("UPDATE `notifications` SET `level` = '$status' WHERE `sysid` = '$usrid'") or die(mysqli_error());
}
else{
	$conn->query("INSERT INTO `notifications`(`ph`, `ec`, `level`, `temp`, `sysid`) VALUES ('','','0','','$usrid') ") or die(mysqli_error());
}


?>