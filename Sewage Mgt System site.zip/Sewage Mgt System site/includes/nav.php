<nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
  <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
    <a class="navbar-brand brand-logo" href="#">
       <img src="assets/images/Logo.png" alt="logo" style="width: 100%"/>  
    </a>
   <!--  <a class="navbar-brand brand-logo-mini" href="#">
      <img src="assets/images/Logo.png" alt="logo" /> 
   </a> -->
  </div>
  <div class="navbar-menu-wrapper d-flex align-items-center">
   
    <ul class="navbar-nav ml-auto">

      <li class="nav-item dropdown">
        <center>SEWAGE MONITORING SYSTEM<small style="color: green;"><strong id="sys_id"><?php echo $_SESSION['username']; ?></strong>  </small> </center>
        
      </li>

    </ul>
    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-right" type="button" data-toggle="offcanvas">
      <span class="mdi mdi-menu"></span>
    </button>
  </div>
</nav>