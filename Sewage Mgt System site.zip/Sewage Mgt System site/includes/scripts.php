<!-- chart for ph / canvas -->
<script type="text/javascript">

        var config = {
            type: 'line',
            data: {
                labels: ["Forth", "Third", "Second", "First"],
                datasets: [{
                	label:  "Last 4 readig",
                    data: [0,0,0,0],
                    fill: false,
                }]
            },
            options: {
            } 
        };

           $.each(config.data.datasets, function(i, dataset) {
            dataset.borderColor = "#09ea14";
            dataset.backgroundColor = "#09ea14";
            dataset.pointBorderColor = "#09ea14";
            dataset.pointBackgroundColor = "#09ea14";
            dataset.pointBorderWidth = 1;
        });

</script>

<!-- chart for temp / canvas -->
<script type="text/javascript">

        var config_temp = {
            type: 'line',
            data: {
                labels: ["Forth", "Third", "Second", "First"],
                datasets: [{
                	label:  "Last 4 readig",
                    data: [0,0,0,0],
                    fill: false,
                }]
            },
            options: {
            } 
        };

           $.each(config_temp.data.datasets, function(i, dataset) {
            dataset.borderColor = "#58d8a3";
            dataset.backgroundColor = "#58d8a3";
            dataset.pointBorderColor = "#58d8a3";
            dataset.pointBackgroundColor = "#58d8a3";
            dataset.pointBorderWidth = 1;
        });

</script>

<!-- chart for EC / canvas -->
<script type="text/javascript">

        var config_ec = {
            type: 'line',
            data: {
                labels: ["Forth", "Third", "Second", "First"],
                datasets: [{
                	label:  "Last 4 readig",
                    data: [0,0,0,0],
                    fill: false,
                }]
            },
            options: {
            } 
        };

           $.each(config_ec.data.datasets, function(i, dataset) {
            dataset.borderColor = "#6610f2";
            dataset.backgroundColor = "#6610f2";
            dataset.pointBorderColor = "#6610f2";
            dataset.pointBackgroundColor = "#6610f2";
            dataset.pointBorderWidth = 1;
        });



</script>

<!-- chart for water levels / canvas -->
<script type="text/javascript">

        var config_water = {
            type: 'line',
            data: {
                labels: ["Forth", "Third", "Second", "First"],
                datasets: [{
                	label: "Last 4 readig",
                    data: [0,0,0,0],
                    fill: false,
                }]
            },
            options: {
            } 
        };

           $.each(config_water.data.datasets, function(i, dataset) {
            dataset.borderColor = "#ffaf00";
            dataset.backgroundColor = "#ffaf00";
            dataset.pointBorderColor = "#ffaf00";
            dataset.pointBackgroundColor = "#ffaf00";
            dataset.pointBorderWidth = 1;
        });

</script>




<script type="text/javascript">

		 window.onload = function() {

            var ctx_ec = document.getElementById("canvas_ec").getContext("2d");
        	chart_ec = new Chart(ctx_ec, config_ec);

            // canvas for Temp 
            var ctx_temp = document.getElementById("canvas_temp").getContext("2d");
        	chart_temp = new Chart(ctx_temp, config_temp);

            // canvas for config_water
            var ctx_water = document.getElementById("canvas_water").getContext("2d");
        	chart_water = new Chart(ctx_water, config_water);
            // canvas for ph
            var ctx = document.getElementById("canvas").getContext("2d");
            chart_ph = new Chart(ctx, config);

        };
</script>


<script type="text/javascript">
    // update ph chart
    function updateconfig_ph(newdataph){
        config.data.datasets[0].data = newdataph;
        chart_ph.update();
    }
    // update water chart
    function updateconfig_water(newdatawat){
        config_water.data.datasets[0].data = newdatawat;
        chart_water.update();
    }
    // update EC chart
    function updateconfig_ec(newdataec){
        config_ec.data.datasets[0].data = newdataec;
        chart_ec.update();
    }
        // update TEMP chart
    function updateconfig_temp(newdatatmp){
        config_temp.data.datasets[0].data = newdatatmp;
        chart_temp.update();
    }

</script>



    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="assets/vendors/js/vendor.bundle.addons.js"></script>
    <script src="assets/js/shared/off-canvas.js"></script>
    <script src="assets/js/demo_1/dashboard.js"></script>
    <!-- <script src="assets/js/shared/jquery.cookie.js" type="text/javascript"></script> -->
  </body>
</html>