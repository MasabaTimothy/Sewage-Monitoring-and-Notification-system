<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    <li class="nav-item nav-profile">
      <a href="#" class="nav-link">
        <div class="profile-image">
          <img class="img-xs rounded-circle" src="assets/images/faces/profile.png" alt="profile image">
          <div class="dot-indicator bg-success"></div>
        </div>
        <div class="text-wrapper">
          <p class="profile-name"><?php echo "ADMIN" ?></p>
        </div>
      </a>
    </li>
    <li class="nav-item nav-category">Main Menu</li>
    <li class="nav-item">
      <a class="nav-link" href="../v1/dashboard.php">
        <i class="menu-icon typcn typcn-document-text"></i>
        <span class="menu-title"><i class="fa-dashboard"></i> Dashboard</span>
      </a>
    </li>
    
         <li class="nav-item">
      <a class="nav-link" href="backup.php">
        <i class="menu-icon typcn typcn-document-text"></i>
        <span class="menu-title">Backup</span>
      </a>
    </li>

             <li class="nav-item">
      <a class="nav-link" href="settings.php">
        <i class="menu-icon typcn typcn-document-text"></i>
        <span class="menu-title">Settings</span>
      </a>
    </li>

     <li class="nav-item">
      <a class="nav-link" href="logout.php">
        <i class="menu-icon typcn typcn-document-text"></i>
        <span class="menu-title">Logout</span>
      </a>
    </li>
    

  </ul>
</nav>