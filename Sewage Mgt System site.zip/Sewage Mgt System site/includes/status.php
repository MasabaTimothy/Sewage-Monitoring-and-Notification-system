<?php

  include '../config/connection.php';
  session_start();
  $sysid = $_SESSION['username'];
  //echo $sysid;
  $status_sql = "SELECT * FROM `status` WHERE sysid = '$sysid'";
  $status_result = $conn->query($status_sql);
   if ($status_result->num_rows > 0) {
              // session_start();
                 while($status_row = $status_result->fetch_assoc()) {

                    $ph = $status_row["ph"];
                    $ec = $status_row["ec"];
                    $temp = $status_row["temp"];
                    $levels = $status_row["levels"];
                    
                 }
                 $total = $ph + $ec + $temp + $levels;
                // $sysecho = $total." %";
                 $sysecho = $total;
                 echo $sysecho;
              // echo"<script>href.Location</script>";
            }
   else{
   		$sysecho = "";
   }         


?>