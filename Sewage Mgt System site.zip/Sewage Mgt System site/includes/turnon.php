<?php

 include '../config/connection.php';

$status = "on";

$conn->query("UPDATE `switching` SET `state` = '$status' WHERE `switchingid` = '1'") or die(mysqli_error());

echo "on";

?>