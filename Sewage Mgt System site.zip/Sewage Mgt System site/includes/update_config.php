<?php
           session_start();
   // $Error = "";
            include '../config/connection.php';
            if(isset($_POST['signin'])){

            unset($_SESSION["account"]);
            $_SESSION['account'] = 'true';
            //$Date=date('d-m-Y');
            $usn=$_POST['usn'];
            $psd=$_POST['psd'];
            $_SESSION['username'] = $usn;
            $sql = "SELECT * FROM `users` WHERE username='$usn' AND password='$psd' AND active='1'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
              // session_start();
                 while($row = $result->fetch_assoc()) {

                    $_SESSION['username'] = $row["username"];
                    $_SESSION['password'] = $row["password"];
                    
                 }
                 if($_SESSION["account"] = "true" ) {
                header("Location: ../dashboard.php");
              }
              // echo"<script>href.Location</script>";
            }
             else {
                $Error = "Ooohs: Wrong Username or Password";
                $_SESSION['error'] = $Error;
                header("Location: ../index.php");
            }


        }
    

?>