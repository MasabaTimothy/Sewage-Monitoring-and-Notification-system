<?php  
  session_start();
  //include 'includes/checksession.php';

    if ($_SESSION['account'] === "true") { /*Preventing one to access the system when a session has not been created*/
        # code...
        header('Location: dashboard.php');
    }


        
        // if ($_GET['registered'] === "sucess") {
          
        //   $Error= "You can now login in";

        // }

  include 'includes/header.php';
?>

      <div class="container-fluid page-body-wrapper full-page-wrapper">
        <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">
          <div class="row w-100">
            <div class="col-lg-4 mx-auto">
              <div class="auto-form-wrapper">
                <form action="includes/update_config.php" method="POST">
                  <div align="center" style="color: red; margin: 5px;">
                    <?php echo $_SESSION['error']; ?>
                  </div>
                  <div class="form-group">
                    <label class="label">Username</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="usn" placeholder="Username" required="">
                      <div class="input-group-append">
                        <span class="input-group-text">
                          <i class="mdi mdi-check-circle-outline"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="label">Password</label>
                    <div class="input-group">
                      <input type="password" class="form-control" name="psd" placeholder="*********" required="">
                      <div class="input-group-append">
                        <span class="input-group-text">
                          <i class="mdi mdi-check-circle-outline"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <button class="btn btn-success submit-btn btn-block" name="signin">Login</button>
                  </div>
                  <div class="form-group d-flex justify-content-between">
                    
                    
                  </div>
                  <div class="text-block text-center my-3">
                    <span class="text-small font-weight-semibold">Not a member ?</span>
                    <a href="register.php" class="text-black text-small">Create new account</a>
                  </div>
                </form>
              </div>
              <ul class="auth-footer">
                <center class="footer-text text-center" >Tel : +256 772 892 166 </center>
              </ul>
              <p class="footer-text text-center">copyright © <?php echo date('Y'); ?>. All rights reserved.</p>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->

 <?php

  include 'includes/scripts.php';

?>