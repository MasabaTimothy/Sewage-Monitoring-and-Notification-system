<?php

  include 'includes/header.php';

?>
      <!--_navbar.php -->

<?php 

    include 'includes/nav.php';

?>
      <!-- partial -->


      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
      
         <?php  
          include 'includes/sidebar.php';
        ?>

        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper"> </div>

          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          
                       <div>
            
  <div class="col-6">
            <div class="row mt-5">
                          <div class="col-6">
                            <div class="mt-n3 ml-auto" id="dashboard-guage-chart"></div>
                          </div>
                        </div>


     </div>
      <div class="col-6">

         <div>

                          <div class="col-6">
                            <div class="mt-n3 ml-auto" id="dashboard-guage-chart"></div>
                          </div>
                          <div class="col-6">
                            <div class="mt-n3 ml-auto" id="dashboard-guage-chart"></div>
                          </div>
        
          </div>
            <div>

                          <div class="col-6">
                            <div class="mt-n3 ml-auto" id="dashboard-guage-chart"></div>
                          </div>
                          <div class="col-6">
                            <div class="mt-n3 ml-auto" id="dashboard-guage-chart"></div>
                          </div>
        
          </div>

    </div>

</div>




<?php 

    include 'includes/footer.php';

?>
      <!-- partial -->