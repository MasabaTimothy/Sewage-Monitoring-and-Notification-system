<?php
include '../config/connection.php';
//set timezones
date_default_timezone_set('Africa/Nairobi');
// sensors readings
$node1= $_GET['node1'];
$node2= $_GET['node2'];
$node3= $_GET['node3'];
$node4= $_GET['node4'];
$sysid= 1234;
$datein= date('Y-m-d');
$timein= date('h:i:s');
//echo ".............................................";
//$query = $conn->query("UPDATE `currentstate` SET `mod1` = '$node_1', `mod2` = '$node_2' WHERE parameterid ='1'"); 

// insert records
$insert_query =  $conn->query("INSERT INTO `datavalues`(`ph`, `temp`, `ec`, `levels`, `sysid`, `timein`, `datein`) VALUES ('$node1','$node2','$node3','$node4','$sysid','$timein','$datein')") or die(mysqli_error());


if ($insert_query) {
	
echo "SUCCESS";

}

$select_query =  $conn->query("SELECT * FROM `switching` WHERE `switchingid` = '1'") or die(mysqli_error());

$act_fetch = $select_query->fetch_array();

$state = $act_fetch['state'];
if($state){
echo $state;

}

else{
echo "OOOOH FAILED";
}

?>