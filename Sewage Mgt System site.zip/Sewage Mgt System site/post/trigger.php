<?php

include '../config/connection.php';


$act_query =  $conn->query("SELECT * FROM `switching` WHERE `switchingid` = '1'") or die(mysqli_error());

$act_fetch = $act_query->fetch_array();

$state = $act_fetch['state'];

echo $state;

?>