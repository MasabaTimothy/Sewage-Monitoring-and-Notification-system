<?php
  session_start();
    
    if (($_SESSION['account'] === "false") || ($_SESSION['account'] == "")) { /*Preventing one to access the system when a session has not been created*/
        # code...
        header('Location: index.php');
    }
       include 'config/connection.php';
       $sysid = $_SESSION['username'];

            $sql = "SELECT * FROM `users` WHERE username=$sysid";
            $result = $conn->query($sql);

             if ($row = $result->fetch_assoc()) {

                 $phone= $row['phone'];
                 $fullname= $row['fullname'];
                 $Email= $row['Email'];
             }

  include 'includes/header.php';
  $_SESSION["error"] = "";


?>
      <!--_navbar.php -->

<?php 

    include 'includes/nav.php';

//     $usrid = $_SESSION['username'];
// $query = "SELECT * FROM `users` WHERE `username` = '$usrid'";

// $result = mysqli_query($conn, $query);

// while ($row = $result->fetch_assoc()) {

//     $sysid =  $row['username'];
//     $fullname =  $row['fullname'];
//     $Email =  $row['Email'];
//     $phone =  $row['phone'];
// }

?>
      <!-- partial -->


      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
      
         <?php  
          include 'includes/sidebar.php';
        ?>

        <!-- partial -->
        <div class="main-panel">

 
          
<!-- 
    <div class="wrapper pr-3 mt-2" style="float: left;">
        
    </div> -->
    <style type="text/css">
            /* Make sure that padding behaves as expected */
            * {box-sizing:border-box}

            /* Container for skill bars */
            .container {
              width: 100%; /* Full width */
             /* background-color: #ddd; /* Grey background */
            }

            .skills {
              text-align: right; /* Right-align text */
              padding-top: 10px; /* Add top padding */
              padding-bottom: 10px; /* Add bottom padding */
              color: white; /* White text color */
            }

            .normal {width: 60%; background-color: #4CAF50;}  /* Green */
            .medium {width: 20%; background-color: #2196F3;} /* Blue */
            .attention {width: 20%; background-color: #f44336;} /* Red */


* {
box-sizing: border-box;
}

/*body {
background: #34495e;
font-family: 'ZCOOL XiaoWei', serif;
display: flex;
align-items: center;
justify-content: center;
height: 100vh;
margin: 0;
}*/

.container {
background: #fff;
display: flex;
align-items: center;
justify-content: center;
flex-direction: column;
overflow: hidden;
text-align: center;
width: 280px;
height: 170px;
}

.container h3 {
color: #111;
margin: 0 0 25px;
position: relative;
z-index: 2;
}

.checkbox-container {
display: inline-block;
position: relative;
}

.checkbox-container label {
background-color: #aaa;
border: 1px solid #fff;
border-radius: 20px;
display: inline-block;
position: relative;
transition: all 0.3s ease-out;
width: 45px;
height: 25px;
z-index: 2;
}

.checkbox-container label::after {
content: ' ';
background-color: #fff;
border-radius: 50%;
position: absolute;
top: 1.5px;
left: 1px;
transform: translateX(0);
transition: transform 0.3s linear;
width: 20px;
height: 20px;
z-index: 3;
}

.checkbox-container input {
visibility: hidden;
position: absolute;
z-index: 2;
}

.checkbox-container input:checked + label + .active-circle {
transform: translate(-50%, -50%) scale(15);
}

.checkbox-container input:checked + label::after {
transform: translateX(calc(100% + 0.5px));
}

.active-circle {
border-radius: 50%;
position: absolute;
top: 50%;
left: 50%;
transform: translate(calc(-50% - 10px), calc(-50% - 2px)) scale(0);
transition: transform 0.6s ease-out;
width: 100px;
height: 100px;
z-index: 1;
}

.checkbox-container.green .active-circle,
.checkbox-container.green input:checked + label {
background-color: #47B881;
}

.checkbox-container.yellow .active-circle,
.checkbox-container.yellow input:checked + label {
background-color: #F7D154;
}

.checkbox-container.purple .active-circle,
.checkbox-container.purple input:checked + label {
background-color: #735DD0;
}

/*css for PH Notification*/
.checkbox-ph-container label {
background-color: #aaa;
border: 1px solid #fff;
border-radius: 20px;
display: inline-block;
position: relative;
transition: all 0.3s ease-out;
width: 45px;
height: 25px;
z-index: 2;
}

.checkbox-ph-container label::after {
content: ' ';
background-color: #fff;
border-radius: 50%;
position: absolute;
top: 1.5px;
left: 1px;
transform: translateX(0);
transition: transform 0.3s linear;
width: 20px;
height: 20px;
z-index: 3;
}

.checkbox-ph-container input {
visibility: hidden;
position: absolute;
z-index: 2;
}

.checkbox-ph-container input:checked + label + .active-circle {
transform: translate(-50%, -50%) scale(15);
}

.checkbox-ph-container input:checked + label::after {
transform: translateX(calc(100% + 0.5px));
}

.active-circle {
border-radius: 50%;
position: absolute;
top: 50%;
left: 50%;
transform: translate(calc(-50% - 10px), calc(-50% - 2px)) scale(0);
transition: transform 0.6s ease-out;
width: 100px;
height: 100px;
z-index: 1;
}

.checkbox-ph-container.green .active-circle,
.checkbox-ph-container.green input:checked + label {
background-color: #47B881;
}

.checkbox-ph-container.yellow .active-circle,
.checkbox-ph-container.yellow input:checked + label {
background-color: #F7D154;
}

.checkbox-ph-container.purple .active-circle,
.checkbox-ph-container.purple input:checked + label {
background-color: #735DD0;
}
    </style> 


      <div class="col-12" style=" margin: 5px; margin-top: 25px;">

                      <div style="float: left;">

                        .
                      </div>


                          <div class="col-9" style="margin-top: 10px; margin: 5px;">

                      <div style="float: left;">


                       <table class="table" style=" color: #757575;">
                            <thead>
                                <tr><th colspan="2"><p style="color:#c3d44c;font-size:20px;"><b>Settings</b></p></th></tr>
                            </thead>
                            <tbody>

                                <tr><td>Name</td><td><b> <?php echo $fullname; ?> </b></td></tr>
                                <tr><td>Email</td><td><b> <?php echo $Email; ?> </b></td></tr>
                                <tr><td>Phone Number</td><td><b><?php echo $phone; ?></b></td></tr>
                              <!--   <tr><td>Max voltage</td><td>12v</td></tr> -->
                            </tbody>
                        </table>

                      </div>
                    </div>

                    <style type="text/css">
                      
                      td {
                        width: 200px;
                         }
                         tr{

                        height: 30px;
                         }
                    </style>

                          <div style="float: left; margin-left: 20px;">

                             <table class="table" style=" color: #757575;">
                            <thead>
                                <tr><th colspan="2"><p style="color:#c3d44c;font-size:20px;"><b>Notifications</b></p></th></tr>
                            </thead>
                            <tbody>

                                <tr class="checkbox-container yellow"><td>Water Level Notifications</td><td mr-0>
                                 <input type="checkbox" id="toggle5" onclick="levelstate();" checked='<?php echo $levelchecker;?>' />
                                 <label for="toggle5">.</label> <span id="status"></span>
                                 <div class="active-circle"></div> 
                              </b></td></tr><tr></tr>

                              <tr class="checkbox-container yellow"><td >pH Notifications</td><td mr-0><b>
                                <input type="checkbox" id="toggle4" onclick="phstate();" checked='<?php echo $checker;?>' /> 
                                 <label for="toggle4">.</label> <span id="status"></span>
                                 <div class="active-circle"></div> 
                              </b></td></tr><tr></tr>

                              <tr class="checkbox-container yellow"><td>EC Notifications</td><td><b>
                                 <input type="checkbox" id="toggle3" onclick="ecstate();" checked='<?php echo $ecchecker;?>'  /> 
                                 <label for="toggle3">.</label> <span id="status"></span>
                                 <div class="active-circle"></div> 
                              </b></td></tr><tr></tr>

                              <tr class="checkbox-container yellow"><td>Temperature Notifications</td><td><b>
                                 <input type="checkbox" id="toggle2" onclick="tempstate();" checked='<?php echo $tempchecker;?>'  /> 
                                 <label for="toggle2">.</label> <span id="status"></span>
                                 <div class="active-circle"></div> 
                              </b></td></tr>
                              <!--   <tr><td>Max voltage</td><td>12v</td></tr> -->
                            </tbody>
                        </table>

                      </div>



</div>



<div style="margin-bottom: 50px;">.</div>

<?php 

    include 'includes/footer.php';

?>
      <!-- partial -->