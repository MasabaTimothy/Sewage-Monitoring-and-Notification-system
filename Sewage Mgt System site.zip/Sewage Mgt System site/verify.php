<?php

 include 'config/connection.php';
              
if(isset($_GET['email']) && !empty($_GET['email']) AND isset($_GET['hash']) && !empty($_GET['hash'])){
    // Verify data
    $email = mysql_escape_string($_GET['email']); // Set email variable
    $hash = mysql_escape_string($_GET['hash']); // Set hash variable
    $sql = "SELECT Email, hash, active FROM users WHERE email='".$email."' AND hash='".$hash."' AND active='0'";              
    //$search = mysql_query() or die(mysql_error()); 
    $search = $conn->query($sql);
    $match  = $search->num_rows
                  
    if($match > 0){
        // We have a match, activate the account
        $update = "UPDATE users SET active='1' WHERE Email='".$email."' AND hash='".$hash."' AND active='0'";
        $updatesearch = $conn->query($update);
        echo '<div class="statusmsg">Your account has been activated, you can now login</div>';
    }else{
        // No match -> invalid url or account has already been activated.
        echo '<div class="statusmsg">The url is either invalid or you already have activated your account.</div>';
    }
                  
}else{
    // Invalid approach
    echo '<div class="statusmsg">Invalid approach, please use the link that has been send to your email.</div>';
}

?>